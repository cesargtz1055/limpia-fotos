# LimpiaFotos — Borra fotos como en Tinder

App Android **nativa** (Kotlin + Jetpack Compose, sin React, sin WebView) para
limpiar la galería del celular deslizando fotos.

## Qué hace

- **Vista Tinder** (`SwipeScreen`): tarjeta grande a casi pantalla completa,
  imagen en alta calidad con Coil, swipe izquierda = marcar para borrar,
  swipe derecha = conservar, botones grandes **Conservar / Borrar**,
  **Saltar** (ver la siguiente sin decidir), **Deshacer** última acción,
  barra de progreso y contadores de sesión.
- **Confirmación en 2 pasos** (lo importante): el primer swipe izquierda
  **NO borra nada**. Solo marca la foto como "Para borrar" y muestra el
  aviso en la tarjeta. El borrado real ocurre solo en el segundo paso:
  en la pantalla **Revisión** (botón "Borrar N" con diálogo de confirmación)
  o con un segundo swipe izquierda sobre esa misma foto en la pila de
  revisión. Ahí se borra con MediaStore; en Android 11+ el sistema muestra
  su propio diálogo de consentimiento (`createDeleteRequest`) y la foto va
  a la **papelera del sistema**, recuperable ~30 días según la app de
  galería (Google Fotos / Galería).
- **Vista Grid tipo Instagram** (`GridScreen`): cuadrícula de 3 columnas,
  agrupada por fecha (**Hoy, Ayer, Esta semana, Este mes, por mes**) y con
  selector de álbum/carpeta (Camera, Screenshots, Descargas…). Al tocar una
  foto se abre la vista Tinder **empezando exactamente desde esa foto**,
  y al volver al grid se mantiene la posición de scroll.
- **Detalle / zoom**: al tocar "Ver detalle / zoom" se abre la foto completa
  con pinch para acercar (hasta 6×) y datos reales: fecha, resolución,
  tamaño en MB, nombre y carpeta.
- **Sesión de limpieza**: contadores de revisadas, conservadas, borradas y
  pendientes. En Revisión se puede **restaurar** una foto antes del borrado
  definitivo o **vaciar** la lista.
- **Diseño**: Material Design 3, modo oscuro por defecto (fondo negro para
  ver bien la calidad), animaciones de swipe con rotación y etiquetas
  BORRAR / CONSERVAR.

## Fotos reales, nada de ejemplo

Las fotos se leen de verdad con `MediaStore` (`PhotoRepository.loadPhotos`,
ordenadas por fecha descendente). No hay fotos de ejemplo ni datos
inventados en la app: si la galería está vacía, la app lo dice y pide el
permiso.

## Estructura

```
limpia-fotos-android/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties   (Gradle 8.7)
└── app/
    ├── build.gradle.kts
    │   (AGP 8.5.2, Kotlin 2.0.21, Compose BOM 2024.09.00, Coil 2.7.0,
    │    Navigation Compose 2.8.0 — versiones estables conocidas)
    ├── src/main/AndroidManifest.xml           (permisos READ_MEDIA_IMAGES…)
    └── src/main/java/com/pulsoscreativos/limpiafotos/
        ├── MainActivity.kt                    (permisos, navegación, diálogo
        │                                      de consentimiento de borrado)
        ├── model/Photo.kt                     (Photo, Decision, SessionStats)
        ├── data/PhotoRepository.kt            (MediaStore: leer + borrar)
        ├── ui/GalleryViewModel.kt             (estado, decisiones, deshacer,
        │                                      agrupación por fecha)
        ├── ui/theme/Theme.kt, Type.kt         (Material 3 oscuro)
        ├── ui/components/SwipeCard.kt         (tarjeta con arrastre/rotación)
        └── ui/screens/
            ├── SwipeScreen.kt  GridScreen.kt
            ├── DetailScreen.kt (zoom pinch)
            └── ReviewScreen.kt (papelera / 2º paso)
```

## Cómo compilar en Android Studio

1. Android Studio **Ladybug o más reciente** (AGP 8.5.2 necesita JDK 17,
   que ya viene incluido en Android Studio).
2. **File → Open** y elige la carpeta `limpia-fotos-android`.
3. Espera a que Gradle sincronice (descarga AGP, Kotlin y las librerías;
   necesita internet la primera vez).
4. Conecta el teléfono por USB con **depuración USB** activada, o usa un
   emulador con fotos.
5. **Run ▶** (o `Shift+F10`). Para generar el APK:
   **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

### Por terminal (si tienes el SDK instalado)

```bash
cd limpia-fotos-android
# En Windows: gradlew.bat assembleDebug
./gradlew assembleDebug
# El APK queda en: app/build/outputs/apk/debug/app-debug.apk
```

> Nota: el proyecto incluye `gradle/wrapper/gradle-wrapper.properties`
> (Gradle 8.7), pero **no incluye el script `gradlew` ni el jar del wrapper**
> (son archivos binarios/generados). Si Android Studio abre el proyecto,
> los genera solo. Por terminal, genera el wrapper una vez con un Gradle
> instalado (`gradle wrapper --gradle-version 8.7`) o usa el de Android
> Studio. Sin `gradlew` ni Android Studio no se puede compilar: es
> limitación del entorno, no del código.

## Instalar en un HONOR X8a (Android)

1. En el teléfono: **Ajustes → Acerca del teléfono → toca 7 veces
   "Número de compilación"** para activar Opciones de desarrollador.
2. **Ajustes → Sistema y actualizaciones → Opciones de desarrollador →
   Depuración USB: activada**.
3. Conecta por USB, acepta "Permitir depuración USB" en el teléfono.
4. Instala el APK de depuración:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   O copia el APK al teléfono y ábrelo desde Archivos (acepta
   "Instalar apps desconocidas" para esa app).

## Permisos que pide (y por qué)

| Permiso | Cuándo | Para qué |
|---|---|---|
| `READ_MEDIA_IMAGES` | Android 13+ | Leer las fotos de la galería |
| `READ_MEDIA_VISUAL_USER_SELECTED` | Android 14 | Que el usuario amplíe la selección de fotos |
| `READ_EXTERNAL_STORAGE` | Android 12 o menos | Lo mismo, en versiones viejas |
| (borrado) | Android 11+ | No es un permiso: el sistema pide confirmación en pantalla cada vez que se borra (`createDeleteRequest`) |

Al abrir la app por primera vez te pedirá acceso a fotos:

- **HONOR X8a** (Android 13/14 según actualización): elige
  **"Permitir todo"** para revisar toda la galería, o
  **"Fotos seleccionadas"** si solo quieres limpiar algunas.
  Con "Fotos seleccionadas" la app solo ve esas fotos; para añadir más,
  ve a **Ajustes → Apps → LimpiaFotos → Permisos → Fotos y vídeos →
  Añadir fotos**.
- Si deniegas el permiso, la app muestra la pantalla de acceso con el
  botón "Dar acceso a fotos" (no se inventan fotos de ejemplo).

## Limitaciones reales (léeme)

1. **Android 14 — fotos seleccionadas**: si el usuario elige solo algunas
   fotos, MediaStore solo devuelve esas. Es decisión del sistema, no un
   bug. Para ver todo hay que elegir "Permitir todo".
2. **El borrado va a la papelera del sistema cuando aplique**: en Android
   11+ con `createDeleteRequest` el sistema mueve la foto a la papelera
   de la app de galería (Google Fotos / Galería HONOR) en vez de
   eliminarla para siempre al instante. La recuperación depende de esa
   app (~30 días en Google Fotos). La app lo explica en la pantalla de
   Revisión y en el diálogo de confirmación.
3. **Consentimiento por borrado**: Android pide confirmación del usuario
   en su propio diálogo cada vez que se ejecuta un borrado (una vez por
   lote, no foto por foto). Si el usuario cancela ahí, no se borra nada.
4. **No se ha compilado en esta máquina**: el código está escrito con
   APIs estables y Gradle coherente (mismas versiones en raíz y app),
   pero no había Android SDK en este entorno para ejecutar
   `./gradlew assembleDebug`. La primera compilación debe hacerse en
   Android Studio o con el SDK instalado; si Gradle reporta un error de
   versión de librería, actualiza solo esa línea en `app/build.gradle.kts`.
5. **Zoom**: pinch hasta 6× con `detectTransformGestures` (Compose nativo,
   sin Accompanist). No hay doble-toque para zoom: pellizca para acercar.
6. **Sin copia de seguridad**: la app no sube ni guarda tus fotos en
   ningún servidor. Todo ocurre en el teléfono. Borrar es borrar (salvo
   la papelera del sistema): revisa la pila de Revisión antes de confirmar.
