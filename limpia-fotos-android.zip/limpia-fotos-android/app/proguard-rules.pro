# Add project specific ProGuard rules here.
# LimpiaFotos 1.0 — minify desactivado en release, este archivo es solo el
# placeholder estándar que exige el build.gradle.kts.
