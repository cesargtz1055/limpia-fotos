package com.pulsoscreativos.limpiafotos

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pulsoscreativos.limpiafotos.ui.GalleryViewModel
import com.pulsoscreativos.limpiafotos.ui.screens.DetailScreen
import com.pulsoscreativos.limpiafotos.ui.screens.GridScreen
import com.pulsoscreativos.limpiafotos.ui.screens.ReviewScreen
import com.pulsoscreativos.limpiafotos.ui.screens.SwipeScreen
import com.pulsoscreativos.limpiafotos.ui.theme.LimpiaFotosTheme

object Routes {
    const val GRID = "grid"
    const val SWIPE = "swipe/{startIndex}"
    const val SWIPE_REVIEW = "swipe_review/{startIndex}"
    const val REVIEW = "review"
    const val DETAIL = "detail/{photoId}"
    fun swipe(startIndex: Int) = "swipe/$startIndex"
    fun swipeReview(startIndex: Int) = "swipe_review/$startIndex"
    fun detail(photoId: Long) = "detail/$photoId"
}

class MainActivity : ComponentActivity() {

    private val vm: GalleryViewModel by viewModels()

    // Permiso de fotos: Android 13+ READ_MEDIA_IMAGES; <=12 READ_EXTERNAL_STORAGE.
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) vm.load() }

    // Diálogo de consentimiento de borrado de Android 11+ (createDeleteRequest).
    // RESULT_OK = el usuario aceptó y el sistema ya borró (a papelera).
    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) vm.onDeleteConsentGranted()
        else vm.onDeleteConsentDenied()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LimpiaFotosTheme(darkTheme = false) {
                App(vm, onRequestPermission = ::requestPhotoPermission)
            }
        }
        if (hasPhotoPermission()) vm.load() else requestPhotoPermission()
    }

    private fun photoPermission(): String =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPhotoPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, photoPermission()) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestPhotoPermission() {
        permissionLauncher.launch(photoPermission())
    }

    /** Llamado desde la UI cuando el ViewModel tiene un IntentSender pendiente. */
    fun launchDeleteConsent() {
        val sender = vm.state.value.pendingConsent ?: return
        deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
    }
}

@Composable
private fun App(vm: GalleryViewModel, onRequestPermission: () -> Unit) {
    val state by vm.state.collectAsState()
    val nav = rememberNavController()
    val gridListState = rememberLazyListState() // mantiene la posición del Grid
    val snackbar = remember { SnackbarHostState() }
    var consentLaunchedFor by remember { mutableStateOf<Any?>(null) }

    // Cuando hay un consentimiento pendiente, lanzarlo una sola vez.
    // Se hace desde la Activity para usar el launcher registrado.
    val activity = androidx.compose.ui.platform.LocalContext.current as? MainActivity
    LaunchedEffect(state.pendingConsent) {
        val sender = state.pendingConsent
        if (sender != null && consentLaunchedFor !== sender) {
            consentLaunchedFor = sender
            activity?.launchDeleteConsent()
        }
    }
    LaunchedEffect(state.message, state.error) {
        (state.message ?: state.error)?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    androidx.compose.material3.Scaffold(
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            NavHost(navController = nav, startDestination = Routes.GRID) {
                composable(Routes.GRID) {
                    if (state.photos.isEmpty() && !state.isLoading) {
                        PermissionEmptyState(onRequestPermission)
                    } else {
                        GridScreen(
                            state = state,
                            viewModel = vm,
                            listState = gridListState, // <-- conserva scroll al volver
                            onPhotoClick = { index -> nav.navigate(Routes.swipe(index)) },
                            onOpenReview = { nav.navigate(Routes.REVIEW) },
                            onStartSwipe = { nav.navigate(Routes.swipe(0)) }
                        )
                    }
                }
                composable(
                    Routes.SWIPE,
                    arguments = listOf(navArgument("startIndex") { type = NavType.IntType })
                ) { backStack ->
                    val start = backStack.arguments?.getInt("startIndex") ?: 0
                    SwipeScreen(
                        state = state, startIndex = start, reviewMode = false,
                        onBack = { nav.popBackStack() },
                        onKeep = vm::keep, onMarkForDelete = vm::markForDelete,
                        onSkip = vm::skip, onUndo = vm::undo,
                        onConfirmDelete = vm::confirmDelete,
                        onOpenDetail = { id -> nav.navigate(Routes.detail(id)) },
                        onOpenReview = { nav.navigate(Routes.REVIEW) }
                    )
                }
                composable(
                    Routes.SWIPE_REVIEW,
                    arguments = listOf(navArgument("startIndex") { type = NavType.IntType })
                ) { backStack ->
                    val start = backStack.arguments?.getInt("startIndex") ?: 0
                    SwipeScreen(
                        state = state, startIndex = start, reviewMode = true,
                        onBack = { nav.popBackStack() },
                        onKeep = vm::keep, onMarkForDelete = vm::markForDelete,
                        onSkip = vm::skip, onUndo = vm::undo,
                        onConfirmDelete = vm::confirmDelete,
                        onOpenDetail = { id -> nav.navigate(Routes.detail(id)) },
                        onOpenReview = { nav.navigate(Routes.REVIEW) }
                    )
                }
                composable(Routes.REVIEW) {
                    ReviewScreen(
                        state = state,
                        onBack = { nav.popBackStack() },
                        onConfirmDeleteAll = vm::confirmDelete,
                        onRestore = vm::restoreFromPending,
                        onOpenSwipeReview = { idx -> nav.navigate(Routes.swipeReview(idx)) }
                    )
                }
                composable(
                    Routes.DETAIL,
                    arguments = listOf(navArgument("photoId") { type = NavType.LongType })
                ) { backStack ->
                    val id = backStack.arguments?.getLong("photoId") ?: -1L
                    val photo = state.photos.firstOrNull { it.id == id }
                    if (photo != null) {
                        DetailScreen(photo = photo, onBack = { nav.popBackStack() })
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Foto no encontrada (puede que ya se haya borrado).")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionEmptyState(onRequestPermission: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Text("LimpiaFotos", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "Para limpiar tu galería necesito acceso a tus fotos. " +
                    "Elige \"Permitir todo\" para revisar todas, o \"Fotos seleccionadas\" " +
                    "si solo quieres limpiar algunas (Android 14).",
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequestPermission) { Text("Dar acceso a fotos") }
        }
    }
}
