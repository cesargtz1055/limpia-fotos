package com.pulsoscreativos.limpiafotos.data

import android.app.RecoverableSecurityException
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.pulsoscreativos.limpiafotos.model.Photo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Resultado de intentar borrar: o se borró, o Android pide consentimiento. */
sealed interface DeleteResult {
    data object Deleted : DeleteResult
    /** En Android 11+ (API 30+) el borrado de fotos ajenas requiere confirmación
     *  del usuario. Lanza este IntentSender con startIntentSenderForResult. */
    data class NeedsConsent(val intentSender: IntentSender) : DeleteResult
}

class PhotoRepository(private val context: Context) {

    private val resolver: ContentResolver get() = context.contentResolver

    /** Lee TODAS las fotos reales de la galería, las más recientes primero. */
    suspend fun loadPhotos(): List<Photo> = withContext(Dispatchers.IO) {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH
        )
        val out = mutableListOf<Photo>()
        resolver.query(
            collection, projection, null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val takenCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
            val wCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val hCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                out += Photo(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    displayName = cursor.getString(nameCol) ?: "Sin nombre",
                    dateAddedSeconds = cursor.getLong(addedCol),
                    dateTakenMillis = cursor.getLong(takenCol),
                    width = cursor.getInt(wCol),
                    height = cursor.getInt(hCol),
                    sizeBytes = cursor.getLong(sizeCol),
                    bucketName = cursor.getString(bucketCol) ?: "Sin álbum",
                    relativePath = cursor.getString(pathCol) ?: ""
                )
            }
        }
        out
    }

    /**
     * Borra fotos con MediaStore.
     * - API 30+: usa [MediaStore.createDeleteRequest] -> el sistema muestra el
     *   diálogo y, si el usuario acepta, la foto va a la papelera del sistema
     *   (Google Fotos / Galería la retiene ~30 días según la app).
     * - API < 30: borrado directo con [ContentResolver.delete]; si el sistema
     *   lanza [RecoverableSecurityException], se devuelve su IntentSender.
     */
    suspend fun deletePhotos(photos: List<Photo>): DeleteResult = withContext(Dispatchers.IO) {
        if (photos.isEmpty()) return@withContext DeleteResult.Deleted
        val uris: List<Uri> = photos.map { it.uri }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val pendingIntent = MediaStore.createDeleteRequest(resolver, uris)
            DeleteResult.NeedsConsent(pendingIntent.intentSender)
        } else {
            try {
                uris.forEach { resolver.delete(it, null, null) }
                DeleteResult.Deleted
            } catch (e: RecoverableSecurityException) {
                DeleteResult.NeedsConsent(e.userAction.actionIntent.intentSender)
            } catch (e: SecurityException) {
                // Sin permiso de escritura en versiones viejas: no hay diálogo
                // recuperable; se propaga como fallo y la UI lo explica.
                throw e
            }
        }
    }
}
