package com.pulsoscreativos.limpiafotos.model

import android.net.Uri

/**
 * Una foto real de la galería (MediaStore). Nada de datos de ejemplo:
 * [id] es el _ID de MediaStore y [uri] es el content:// que Coil carga.
 */
data class Photo(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val dateAddedSeconds: Long, // DATE_ADDED (segundos desde epoch)
    val dateTakenMillis: Long, // DATE_TAKEN (ms) o DATE_ADDED*1000 si no hay
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val bucketName: String, // carpeta / álbum (p. ej. "Camera", "Screenshots")
    val relativePath: String
) {
    val dateMillis: Long get() = if (dateTakenMillis > 0) dateTakenMillis else dateAddedSeconds * 1000L
    val resolution: String get() = "${width} × ${height}"
    val sizeMb: String get() = "%.1f MB".format(sizeBytes / 1024f / 1024f)
    val sizeText: String get() = if (sizeBytes >= 1024 * 1024) sizeMb
        else "%.0f KB".format(sizeBytes / 1024f)
}

/** Decisión del usuario sobre una foto en la sesión actual. */
enum class Decision { UNDECIDED, KEEP, MARKED_FOR_DELETE, SKIPPED }

data class SessionStats(
    val reviewed: Int = 0,
    val kept: Int = 0,
    val marked: Int = 0, // en revisión, aún NO borradas
    val deleted: Int = 0,
    val skipped: Int = 0
)
