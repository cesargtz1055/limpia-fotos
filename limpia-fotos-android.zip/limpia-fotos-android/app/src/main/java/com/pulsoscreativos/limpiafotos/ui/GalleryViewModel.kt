package com.pulsoscreativos.limpiafotos.ui

import android.app.Application
import android.content.IntentSender
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pulsoscreativos.limpiafotos.data.DeleteResult
import com.pulsoscreativos.limpiafotos.data.PhotoRepository
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.model.SessionStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class GalleryUiState(
    val photos: List<Photo> = emptyList(),
    val isLoading: Boolean = true,
    val decisions: Map<Long, Decision> = emptyMap(),
    /** Pila para Deshacer: (photoId, decisión anterior). */
    val undoStack: List<Pair<Long, Decision>> = emptyList(),
    val selectedAlbum: String? = null, // null = todos
    val stats: SessionStats = SessionStats(),
    /** Fotos pendientes de borrar (2º paso). Se confirman en la pantalla Revisión. */
    val pendingDelete: List<Photo> = emptyList(),
    /** Lote exacto que se está intentando borrar (puede ser 1 foto o todas). */
    val deleteRequest: List<Photo> = emptyList(),
    val pendingConsent: IntentSender? = null,
    val message: String? = null,
    val error: String? = null
) {
    val albums: List<String> get() = photos.map { it.bucketName }.distinct().sorted()
    val visiblePhotos: List<Photo>
        get() = if (selectedAlbum == null) photos else photos.filter { it.bucketName == selectedAlbum }
}

class GalleryViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = PhotoRepository(application)
    private val _state = MutableStateFlow(GalleryUiState())
    val state: StateFlow<GalleryUiState> = _state.asStateFlow()

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            runCatching { repo.loadPhotos() }
                .onSuccess { list -> _state.update { it.copy(photos = list, isLoading = false) } }
                .onFailure { e -> _state.update { it.copy(isLoading = false, error = e.message) } }
        }
    }

    fun selectAlbum(album: String?) = _state.update { it.copy(selectedAlbum = album) }

    private fun decide(photoId: Long, decision: Decision) {
        _state.update { s ->
            val prev = s.decisions[photoId] ?: Decision.UNDECIDED
            val newDecisions = s.decisions + (photoId to decision)
            s.copy(
                decisions = newDecisions,
                undoStack = s.undoStack + (photoId to prev),
                stats = s.stats.copy(
                    reviewed = newDecisions.count { it.value != Decision.UNDECIDED },
                    kept = newDecisions.count { it.value == Decision.KEEP },
                    marked = newDecisions.count { it.value == Decision.MARKED_FOR_DELETE },
                    skipped = newDecisions.count { it.value == Decision.SKIPPED }
                ),
                pendingDelete = s.photos.filter { newDecisions[it.id] == Decision.MARKED_FOR_DELETE }
            )
        }
    }

    fun keep(photoId: Long) = decide(photoId, Decision.KEEP)
    fun markForDelete(photoId: Long) = decide(photoId, Decision.MARKED_FOR_DELETE)
    fun skip(photoId: Long) = decide(photoId, Decision.SKIPPED)

    /** Deshacer la última acción (conservar / marcar / saltar). */
    fun undo() {
        _state.update { s ->
            val last = s.undoStack.lastOrNull() ?: return@update s
            val (id, prev) = last
            val newDecisions = if (prev == Decision.UNDECIDED) s.decisions - id else s.decisions + (id to prev)
            s.copy(
                decisions = newDecisions,
                undoStack = s.undoStack.dropLast(1),
                stats = s.stats.copy(
                    reviewed = newDecisions.count { it.value != Decision.UNDECIDED },
                    kept = newDecisions.count { it.value == Decision.KEEP },
                    marked = newDecisions.count { it.value == Decision.MARKED_FOR_DELETE },
                    skipped = newDecisions.count { it.value == Decision.SKIPPED }
                ),
                pendingDelete = s.photos.filter { newDecisions[it.id] == Decision.MARKED_FOR_DELETE }
            )
        }
    }

    /** Sacar una foto de la pila de revisión (restaurar a sin decidir). */
    fun restoreFromPending(photoId: Long) {
        _state.update { s ->
            val newDecisions = s.decisions - photoId
            s.copy(
                decisions = newDecisions,
                stats = s.stats.copy(
                    marked = newDecisions.count { it.value == Decision.MARKED_FOR_DELETE },
                    reviewed = newDecisions.count { it.value != Decision.UNDECIDED }
                ),
                pendingDelete = s.photos.filter { newDecisions[it.id] == Decision.MARKED_FOR_DELETE },
                message = "Foto restaurada"
            )
        }
    }

    /**
     * SEGUNDO PASO: borrado real. Se llama solo desde la pantalla de Revisión
     * (botón Confirmar) o desde el 2º swipe izquierda en esa pila.
     * En API 30+ devuelve un IntentSender: la Activity lo lanza y el sistema
     * pide confirmación; al aceptar, [onDeleteConsentGranted] confirma el borrado.
     */
    fun confirmDelete(photosToDelete: List<Photo>) {
        _state.update { it.copy(deleteRequest = photosToDelete) }
        viewModelScope.launch {
            runCatching { repo.deletePhotos(photosToDelete) }
                .onSuccess { result ->
                    when (result) {
                        is DeleteResult.Deleted -> applyDeleted(photosToDelete)
                        is DeleteResult.NeedsConsent ->
                            _state.update { it.copy(pendingConsent = result.intentSender) }
                    }
                }
                .onFailure { e -> _state.update { it.copy(error = "No se pudo borrar: ${e.message}") } }
        }
    }

    /** El usuario aceptó el diálogo del sistema: el borrado ya se ejecutó.
     *  Se aplica SOLO al lote que se pidió borrar, no a toda la pila. */
    fun onDeleteConsentGranted() {
        val requested = _state.value.deleteRequest
        _state.update { it.copy(pendingConsent = null, deleteRequest = emptyList()) }
        applyDeleted(requested)
    }

    fun onDeleteConsentDenied() {
        _state.update {
            it.copy(pendingConsent = null, deleteRequest = emptyList(), error = "Borrado cancelado: no se borró nada.")
        }
    }

    private fun applyDeleted(deleted: List<Photo>) {
        val ids = deleted.map { it.id }.toSet()
        _state.update { s ->
            val remaining = s.photos.filterNot { it.id in ids }
            val newDecisions = s.decisions - ids
            s.copy(
                photos = remaining,
                decisions = newDecisions,
                // Quedan pendientes solo las marcadas que NO se borraron.
                pendingDelete = remaining.filter { newDecisions[it.id] == Decision.MARKED_FOR_DELETE },
                stats = s.stats.copy(
                    deleted = s.stats.deleted + deleted.size,
                    // Las borradas ya contaban como revisadas cuando se marcaron;
                    // no se suman de nuevo. Solo se descuentan de "marcadas".
                    marked = newDecisions.count { it.value == Decision.MARKED_FOR_DELETE }
                ),
                message = "Foto(s) enviada(s) a la papelera del sistema"
            )
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null, error = null) }

    // ---- Agrupación por fecha para el Grid tipo Instagram ----
    fun dateLabel(photo: Photo): String {
        val zone = ZoneId.systemDefault()
        val date = Instant.ofEpochMilli(photo.dateMillis).atZone(zone).toLocalDate()
        val today = LocalDate.now(zone)
        return when {
            date == today -> "Hoy"
            date == today.minusDays(1) -> "Ayer"
            date.isAfter(today.minusDays(7)) -> "Esta semana"
            date.isAfter(today.minusMonths(1)) -> "Este mes"
            else -> date.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("es", "MX")))
                .replaceFirstChar { it.uppercase() }
        }
    }

    fun dateLabelForSection(photosInSection: List<Photo>): String =
        photosInSection.firstOrNull()?.let { dateLabel(it) } ?: ""
}
