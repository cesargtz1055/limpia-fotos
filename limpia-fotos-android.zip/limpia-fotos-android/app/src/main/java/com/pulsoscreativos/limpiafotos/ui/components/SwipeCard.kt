package com.pulsoscreativos.limpiafotos.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class SwipeDirection { LEFT, RIGHT }

/**
 * Tarjeta Tinder: arrastre con rotación, etiquetas BORRAR / CONSERVAR que
 * aparecen según la dirección, y animación de salida. Si el arrastre no
 * supera el umbral, la tarjeta vuelve al centro.
 * En la pila de Revisión, deslizar a la izquierda es la 2ª confirmación.
 */
@Composable
fun SwipeCard(
    photo: Photo,
    decision: Decision,
    modifier: Modifier = Modifier,
    onSwipe: (SwipeDirection) -> Unit,
    onTap: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }
    val offsetY = remember { Animatable(0f) }
    val config = LocalConfiguration.current
    val density = LocalDensity.current
    val screenWidthPx = with(density) { config.screenWidthDp.dp.toPx() }
    val threshold = screenWidthPx * 0.28f
    val rotation = (offsetX.value / screenWidthPx) * 12f
    val isMarked = decision == Decision.MARKED_FOR_DELETE

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                translationX = offsetX.value
                translationY = offsetY.value
                rotationZ = rotation
            }
            .pointerInput(photo.id) {
                detectDragGestures(
                    onDragEnd = {
                        scope.launch {
                            when {
                                offsetX.value < -threshold -> {
                                    offsetX.animateTo(-screenWidthPx * 1.5f, tween(220))
                                    onSwipe(SwipeDirection.LEFT)
                                    offsetX.snapTo(0f); offsetY.snapTo(0f)
                                }
                                offsetX.value > threshold -> {
                                    offsetX.animateTo(screenWidthPx * 1.5f, tween(220))
                                    onSwipe(SwipeDirection.RIGHT)
                                    offsetX.snapTo(0f); offsetY.snapTo(0f)
                                }
                                else -> {
                                    offsetX.animateTo(0f, tween(250))
                                    offsetY.animateTo(0f, tween(250))
                                }
                            }
                        }
                    }
                ) { change, dragAmount ->
                    change.consume()
                    scope.launch {
                        offsetX.snapTo(offsetX.value + dragAmount.x)
                        offsetY.snapTo(offsetY.value + dragAmount.y)
                    }
                }
            }
    ) {
        // Imagen en alta calidad: Coil carga el content:// original sin
        // comprimir; ContentScale.Crop llena la tarjeta sin deformar.
        AsyncImage(
            model = photo.uri,
            contentDescription = photo.displayName,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(24.dp))
                .border(
                    width = if (isMarked) 3.dp else 0.dp,
                    color = if (isMarked) Color(0xFFE5484D) else Color.Transparent,
                    shape = RoundedCornerShape(24.dp)
                )
        )

        // Etiqueta BORRAR (al arrastrar a la izquierda)
        if (offsetX.value < -40f) {
            SwipeLabel(
                text = if (isMarked) "¡CONFIRMAR BORRADO!" else "BORRAR",
                color = Color(0xFFE5484D),
                modifier = Modifier.align(Alignment.TopEnd).padding(20.dp).rotate(12f),
                alpha = (abs(offsetX.value) / threshold).coerceIn(0f, 1f)
            )
        }
        // Etiqueta CONSERVAR (al arrastrar a la derecha)
        if (offsetX.value > 40f) {
            SwipeLabel(
                text = "CONSERVAR",
                color = Color(0xFF4ADE80),
                modifier = Modifier.align(Alignment.TopStart).padding(20.dp).rotate(-12f),
                alpha = (abs(offsetX.value) / threshold).coerceIn(0f, 1f)
            )
        }
        // Estado "Para borrar": la foto ya está marcada, falta el 2º paso.
        if (isMarked) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp, start = 16.dp, end = 16.dp)
                    .background(Color(0xFFE5484D), RoundedCornerShape(999.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    "Para borrar — confírmala en Revisión",
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
        }
        // Nota: el tap para abrir el zoom/detalle se resuelve en la pantalla
        // (SwipeScreen) con un botón "Ver detalle" bajo la tarjeta, para no
        // competir con el gesto de arrastre. onTap se conserva en la firma
        // para ese uso futuro sin romper la API del componente.
        @Suppress("UNUSED_PARAMETER")
        val ignoredTap = onTap
    }
}

@Composable
private fun SwipeLabel(text: String, color: Color, modifier: Modifier, alpha: Float) {
    Text(
        text = text,
        color = color.copy(alpha = alpha),
        style = MaterialTheme.typography.titleLarge,
        modifier = modifier.border(3.dp, color.copy(alpha = alpha), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}
