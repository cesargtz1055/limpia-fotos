package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pulsoscreativos.limpiafotos.model.Photo
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Detalle / zoom: pinch para acercar (detectTransformGestures, sin librerías),
 * doble toque no incluido a propósito para no pelear con el pinch.
 * Muestra fecha, resolución, tamaño, nombre y carpeta — lo necesario para
 * juzgar la calidad antes de borrar.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(photo: Photo, onBack: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val dateText = remember(photo) {
        Instant.ofEpochMilli(photo.dateMillis)
            .atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("d 'de' MMMM yyyy, HH:mm", Locale("es", "MX")))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(photo.displayName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            // Solo desplazar cuando hay zoom; si no, recentrar.
                            offset = if (scale > 1f) offset + pan else Offset.Zero
                        }
                    }
            ) {
                AsyncImage(
                    model = photo.uri,
                    contentDescription = photo.displayName,
                    // Fit para ver la foto completa y juzgar calidad sin recorte.
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        }
                )
            }
            Column(Modifier.padding(16.dp)) {
                Text("Fecha: $dateText", style = MaterialTheme.typography.bodyLarge)
                Text("Resolución: ${photo.resolution}", style = MaterialTheme.typography.bodyLarge)
                Text("Tamaño: ${photo.sizeText}", style = MaterialTheme.typography.bodyLarge)
                Text("Nombre: ${photo.displayName}", style = MaterialTheme.typography.bodyMedium)
                Text("Carpeta / álbum: ${photo.bucketName}", style = MaterialTheme.typography.bodyMedium)
                if (photo.relativePath.isNotBlank()) {
                    Text("Ruta: ${photo.relativePath}", style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    "Pellizca para acercar y ver el detalle. Arrastra con dos dedos cuando hay zoom.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
