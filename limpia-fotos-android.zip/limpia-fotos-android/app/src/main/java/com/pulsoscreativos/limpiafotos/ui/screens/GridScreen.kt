package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState
import com.pulsoscreativos.limpiafotos.ui.GalleryViewModel

/**
 * Vista Grid tipo perfil de Instagram: 3 columnas, agrupada por fecha
 * (Hoy / Ayer / Esta semana / Este mes / por mes) y selector de álbum.
 * Al tocar una foto se abre la vista Tinder empezando EN ESA foto.
 * [listState] se conserva en MainActivity: al volver, el grid mantiene
 * la posición de scroll.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridScreen(
    state: GalleryUiState,
    viewModel: GalleryViewModel,
    listState: LazyListState,
    onPhotoClick: (Int) -> Unit, // índice dentro de state.visiblePhotos
    onOpenReview: () -> Unit,
    onStartSwipe: () -> Unit
) {
    // Agrupar las fotos visibles por etiqueta de fecha, en orden.
    val sections: List<Pair<String, List<Photo>>> = remember(state.visiblePhotos) {
        val grouped = linkedMapOf<String, MutableList<Photo>>()
        state.visiblePhotos.forEach { photo ->
            grouped.getOrPut(viewModel.dateLabel(photo)) { mutableListOf() } += photo
        }
        grouped.map { it.key to it.value.toList() }
    }
    // Índice global de cada foto dentro de visiblePhotos (para entrar a Tinder).
    val indexById: Map<Long, Int> = remember(state.visiblePhotos) {
        state.visiblePhotos.mapIndexed { i, p -> p.id to i }.toMap()
    }

    Scaffold(
        containerColor = Color(0xFFF2F2F4),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Mis fotos",
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        maxLines = 1
                    )
                },
                actions = {
                    androidx.compose.material3.TextButton(onClick = onOpenReview) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Text("Revisión (${state.pendingDelete.size})")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // Estadísticas estilo perfil de Instagram: 3 columnas.
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ProfileStat("${state.visiblePhotos.size}", "fotos")
                ProfileStat("${state.stats.kept}", "guardadas")
                ProfileStat("${state.stats.marked}", "para borrar")
            }
            // Selector de álbum / carpeta: píldoras horizontales, estilo Instagram.
            androidx.compose.foundation.lazy.LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    AlbumChip(
                        label = "Todos",
                        selected = state.selectedAlbum == null,
                        onClick = { viewModel.selectAlbum(null) }
                    )
                }
                items(state.albums) { album ->
                    AlbumChip(
                        label = album,
                        selected = state.selectedAlbum == album,
                        onClick = { viewModel.selectAlbum(album) }
                    )
                }
            }
            androidx.compose.material3.Button(
                onClick = onStartSwipe,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF111111)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .height(48.dp)
            ) { Text("Empezar a revisar", color = Color.White) }

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }
            if (state.visiblePhotos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay fotos en la galería")
                }
                return@Column
            }

            // Secciones por fecha; cada sección es un grid de 3 columnas,
            // estilo perfil de Instagram: a sangre, sin bordes ni radios.
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                items(sections, key = { it.first }) { (label, photos) ->
                    Text(
                        label,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 12.dp)
                    )
                    val rows = photos.chunked(3)
                    rows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            row.forEach { photo ->
                                val marked = (state.decisions[photo.id] ?: Decision.UNDECIDED) ==
                                    Decision.MARKED_FOR_DELETE
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clickable {
                                            indexById[photo.id]?.let { onPhotoClick(it) }
                                        }
                                ) {
                                    AsyncImage(
                                        model = photo.uri,
                                        contentDescription = photo.displayName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    if (marked) {
                                        Box(
                                            Modifier.fillMaxSize()
                                                .background(Color(0xFFF43F4E).copy(alpha = 0.45f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Filled.Delete, null,
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                            // Rellenar la última fila incompleta
                            repeat(3 - row.size) { SpacerCell() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.SpacerCell() {
    Box(Modifier.weight(1f).aspectRatio(1f))
}

@Composable
private fun ProfileStat(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            number,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1
        )
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF6B7280),
            maxLines = 1
        )
    }
}

@Composable
private fun AlbumChip(label: String, selected: Boolean, onClick: () -> Unit) {
    androidx.compose.material3.Button(
        onClick = onClick,
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
            containerColor = if (selected) Color(0xFF17171C) else Color.White,
            contentColor = if (selected) Color.White else Color(0xFF55555F)
        ),
        shape = RoundedCornerShape(999.dp),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
        modifier = Modifier.height(36.dp)
    ) {
        Text(label, maxLines = 1)
    }
}
