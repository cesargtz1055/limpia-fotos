package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState
import com.pulsoscreativos.limpiafotos.ui.GalleryViewModel

/**
 * Vista Grid tipo perfil de Instagram: 3 columnas, agrupada por fecha
 * (Hoy / Ayer / Esta semana / Este mes / por mes) y selector de álbum.
 * Al tocar una foto se abre la vista Tinder empezando EN ESA foto.
 * [listState] se conserva en MainActivity: al volver, el grid mantiene
 * la posición de scroll.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridScreen(
    state: GalleryUiState,
    viewModel: GalleryViewModel,
    listState: LazyListState,
    onPhotoClick: (Int) -> Unit, // índice dentro de state.visiblePhotos
    onOpenReview: () -> Unit,
    onStartSwipe: () -> Unit
) {
    // Agrupar las fotos visibles por etiqueta de fecha, en orden.
    val sections: List<Pair<String, List<Photo>>> = remember(state.visiblePhotos) {
        val grouped = linkedMapOf<String, MutableList<Photo>>()
        state.visiblePhotos.forEach { photo ->
            grouped.getOrPut(viewModel.dateLabel(photo)) { mutableListOf() } += photo
        }
        grouped.map { it.key to it.value.toList() }
    }
    // Índice global de cada foto dentro de visiblePhotos (para entrar a Tinder).
    val indexById: Map<Long, Int> = remember(state.visiblePhotos) {
        state.visiblePhotos.mapIndexed { i, p -> p.id to i }.toMap()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mis fotos (${state.visiblePhotos.size})") },
                actions = {
                    androidx.compose.material3.TextButton(onClick = onOpenReview) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Text("Revisión (${state.pendingDelete.size})")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // Contadores de sesión
            Text(
                "Revisadas ${state.stats.reviewed}  •  Conservadas ${state.stats.kept}  •  " +
                    "Para borrar ${state.stats.marked}  •  Borradas ${state.stats.deleted}",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            // Selector de álbum / carpeta (chips horizontales)
            androidx.compose.foundation.lazy.LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    AssistChip(
                        onClick = { viewModel.selectAlbum(null) },
                        label = { Text("Todos") },
                        leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null) }
                    )
                }
                items(state.albums) { album ->
                    AssistChip(
                        onClick = { viewModel.selectAlbum(album) },
                        label = { Text(album) }
                    )
                }
            }
            androidx.compose.material3.TextButton(
                onClick = onStartSwipe,
                modifier = Modifier.padding(start = 8.dp)
            ) { Text("▶ Empezar a revisar como Tinder") }

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }
            if (state.visiblePhotos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay fotos en la galería")
                }
                return@Column
            }

            // Secciones por fecha; cada sección es un grid de 3 columnas.
            // LazyColumn + LazyVerticalGrid anidado con altura fija por sección
            // es la forma simple y estable sin librerías extra.
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                items(sections, key = { it.first }) { (label, photos) ->
                    Text(
                        label,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                    // Grid de 3 columnas: usamos un grid no-scrollable dentro
                    // de la LazyColumn (altura calculada por filas).
                    val rows = photos.chunked(3)
                    rows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            row.forEach { photo ->
                                val marked = (state.decisions[photo.id] ?: Decision.UNDECIDED) ==
                                    Decision.MARKED_FOR_DELETE
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .clickable {
                                            indexById[photo.id]?.let { onPhotoClick(it) }
                                        }
                                ) {
                                    AsyncImage(
                                        model = photo.uri,
                                        contentDescription = photo.displayName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    if (marked) {
                                        Box(
                                            Modifier.fillMaxSize()
                                                .background(Color(0xFFE5484D).copy(alpha = 0.45f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                Icons.Filled.Delete, null,
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                            // Rellenar la última fila incompleta
                            repeat(3 - row.size) { SpacerCell() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.SpacerCell() {
    Box(Modifier.weight(1f).aspectRatio(1f))
}
