package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState

/**
 * Papelera / Revisión pendiente (2º PASO).
 * Aquí están solo las fotos marcadas con el 1er swipe. Nada se borró aún.
 * - "Vaciar / Borrar definitivo": abre confirmación y borra con MediaStore
 *   (en Android 11+ el sistema pide su propio consentimiento y la foto va
 *   a la papelera del sistema, recuperable ~30 días según la app de galería).
 * - "Restaurar": saca la foto de la lista sin borrarla.
 * - Tocar una foto abre la vista Tinder en modo revisión, empezando en ella:
 *   2º swipe izquierda ahí también confirma el borrado de esa foto.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewScreen(
    state: GalleryUiState,
    onBack: () -> Unit,
    onConfirmDeleteAll: (List<Photo>) -> Unit,
    onRestore: (Long) -> Unit,
    onOpenSwipeReview: (Int) -> Unit
) {
    var showConfirm by remember { mutableStateOf(false) }
    val pending = state.pendingDelete

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("¿Borrar ${pending.size} foto(s)?") },
            text = {
                Text(
                    "Se enviarán a la papelera del sistema (cuando aplique). " +
                        "Android te pedirá confirmación y podrás recuperarlas " +
                        "desde la papelera de tu galería durante unos 30 días."
                )
            },
            confirmButton = {
                Button(
                    onClick = { showConfirm = false; onConfirmDeleteAll(pending) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF43F4E))
                ) { Text("Borrar definitivo") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("Cancelar") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Para borrar (${pending.size})") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "Nada se ha borrado todavía. Revisa, restaura lo que quieras " +
                    "conservar, o confirma el borrado. El borrado usa la papelera " +
                    "del sistema cuando está disponible.",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { showConfirm = true },
                    enabled = pending.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF43F4E)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Delete, null)
                    Text("Borrar ${pending.size}")
                }
                OutlinedButton(
                    onClick = { onOpenSwipeReview(0) },
                    enabled = pending.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) { Text("Revisar una a una") }
            }
            if (pending.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nada pendiente. Desliza a la izquierda para marcar fotos.")
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(pending, key = { it.id }) { photo ->
                        Box(
                            modifier = Modifier.aspectRatio(1f),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            AsyncImage(
                                model = photo.uri,
                                contentDescription = photo.displayName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                IconButton(onClick = { onRestore(photo.id) }) {
                                    Icon(Icons.Filled.Restore, null, tint = Color.White)
                                }
                                IconButton(onClick = {
                                    val idx = pending.indexOf(photo)
                                    onOpenSwipeReview(idx)
                                }) {
                                    Icon(Icons.Filled.Delete, null, tint = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
