package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState
import com.pulsoscreativos.limpiafotos.ui.components.SwipeCard
import com.pulsoscreativos.limpiafotos.ui.components.SwipeDirection

// Colores exactos de la demo aprobada (archivo HTML de Cesar).
private val DemoBg = Color(0xFFF2F2F4)
private val DemoRed = Color(0xFFF43F4E)
private val DemoGreen = Color(0xFF17B978)
private val DemoAmber = Color(0xFFE8930C)
private val DemoInk = Color(0xFF17171C)
private val DemoInk2 = Color(0xFF55555F)
private val DemoInk3 = Color(0xFF8B8B96)
private val DemoLine = Color(0x17171C).copy(alpha = 0.09f)

/**
 * Vista Tinder, literal a la demo aprobada por Cesar (v1.4).
 * - Fondo #F2F2F4, rojo #F43F4E, verde #17B978, ámbar #E8930C.
 * - Header con marca degradada roja + "LimpiaFotos".
 * - Tarjeta radio 26 dp, sombra fuerte, datos sobre la foto.
 * - Acciones EXACTAS de la demo: solo 3 botones — Deshacer 50 dp ámbar,
 *   Borrar (✕) 68 dp rojo, Conservar (✓) 68 dp verde. Círculos blancos
 *   con borde fino y sombra. Sin Saltar, sin corazón, sin zoom en botones:
 *   saltar es la tira "Siguientes" y zoom es tocar la foto.
 * - Swipe izquierda = marcar para borrar (PASO 1, no borra).
 * - Swipe derecha = conservar.
 * - Si [reviewMode] es true, recorre solo la pila "Para borrar":
 *   swipe izquierda aquí = 2ª confirmación -> borra de verdad.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeScreen(
    state: GalleryUiState,
    startIndex: Int,
    reviewMode: Boolean = false,
    onBack: () -> Unit,
    onKeep: (Long) -> Unit,
    onMarkForDelete: (Long) -> Unit,
    onSkip: (Long) -> Unit,
    onUndo: () -> Unit,
    onConfirmDelete: (List<Photo>) -> Unit,
    onOpenDetail: (Long) -> Unit,
    onOpenReview: () -> Unit
) {
    val deck: List<Photo> = remember(state.photos, state.selectedAlbum, reviewMode) {
        if (reviewMode) state.pendingDelete else state.visiblePhotos
    }
    var index by remember(deck) { mutableIntStateOf(startIndex.coerceIn(0, (deck.size - 1).coerceAtLeast(0))) }
    val current: Photo? = deck.getOrNull(index)
    val total = state.visiblePhotos.size.coerceAtLeast(1)
    val reviewed = state.stats.reviewed
    // Siguientes: las 3 fotos que vienen después de la actual.
    val nextPhotos: List<Photo> = remember(deck, index) {
        deck.subList((index + 1).coerceAtMost(deck.size), minOf(index + 4, deck.size))
    }

    Scaffold(
        containerColor = DemoBg
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header de la demo: marca degradada + LimpiaFotos.
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = DemoInk)
                }
                Box(
                    modifier = Modifier.size(32.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFFFF5F6D), DemoRed, Color(0xFFC81E3A))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Menu, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(9.dp))
                Text(
                    if (reviewMode) "Revisión" else "LimpiaFotos",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = DemoInk,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (!reviewMode && state.pendingDelete.isNotEmpty()) {
                    FilledTonalButton(
                        onClick = onOpenReview,
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Revisión (${state.pendingDelete.size})", fontSize = 13.sp, maxLines = 1)
                    }
                }
            }

            // Progreso fino + contador, en una línea.
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { reviewed.toFloat() / total.toFloat() },
                    modifier = Modifier.weight(1f).height(3.dp),
                    color = DemoRed,
                    trackColor = Color(0xFFE9E9EE)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    "$reviewed / $total",
                    fontSize = 12.sp,
                    color = DemoInk2,
                    maxLines = 1
                )
            }

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }

            if (current == null) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (reviewMode) "Nada pendiente de borrar."
                            else "¡Ya revisaste todas las fotos!",
                            style = MaterialTheme.typography.titleLarge,
                            color = DemoInk
                        )
                        Spacer(Modifier.height(16.dp))
                        if (!reviewMode && state.pendingDelete.isNotEmpty()) {
                            Button(onClick = onOpenReview) {
                                Text("Ir a revisión (${state.pendingDelete.size})")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onBack) { Text("Volver al grid") }
                    }
                }
                return@Column
            }

            val decision = state.decisions[current.id] ?: Decision.UNDECIDED
            val onDeleteClick: () -> Unit = {
                if (reviewMode) onConfirmDelete(listOf(current))
                else { onMarkForDelete(current.id); index += 1 }
            }
            val onKeepClick: () -> Unit = {
                if (reviewMode) index += 1 else { onKeep(current.id); index += 1 }
            }

            // Tarjeta grande, radio 26 dp como la demo.
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 14.dp)
                    .shadow(18.dp, RoundedCornerShape(26.dp))
            ) {
                SwipeCard(
                    photo = current,
                    decision = decision,
                    onTap = { onOpenDetail(current.id) },
                    onSwipe = { dir ->
                        when (dir) {
                            SwipeDirection.LEFT -> {
                                if (reviewMode) onConfirmDelete(listOf(current))
                                else onMarkForDelete(current.id)
                                index += 1
                            }
                            SwipeDirection.RIGHT -> {
                                if (!reviewMode) onKeep(current.id)
                                index += 1
                            }
                        }
                    }
                )
            }

            // Tira "Siguientes" de la demo: miniaturas para saltar a ellas.
            if (nextPhotos.isNotEmpty()) {
                Text(
                    "SIGUIENTES · TOCA UNA PARA SALTAR A ELLA",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DemoInk3,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    nextPhotos.forEach { photo ->
                        AsyncImage(
                            model = photo.uri,
                            contentDescription = photo.displayName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.weight(1f).height(68.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    val target = deck.indexOf(photo)
                                    if (target >= 0) {
                                        onSkip(current.id)
                                        index = target
                                    }
                                }
                        )
                    }
                }
            }

            // Acciones EXACTAS de la demo: solo Deshacer, Borrar, Conservar.
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                DemoActionButton(
                    onClick = onUndo,
                    enabled = state.undoStack.isNotEmpty(),
                    icon = Icons.Filled.Undo,
                    tint = DemoAmber,
                    description = "Deshacer última decisión",
                    size = 50.dp,
                    iconSize = 22.dp
                )
                Spacer(Modifier.width(18.dp))
                DemoActionButton(
                    onClick = onDeleteClick,
                    icon = Icons.Filled.Close,
                    tint = DemoRed,
                    description = "Mandar a la papelera",
                    size = 68.dp,
                    iconSize = 30.dp
                )
                Spacer(Modifier.width(18.dp))
                DemoActionButton(
                    onClick = onKeepClick,
                    icon = Icons.Filled.Check,
                    tint = DemoGreen,
                    description = "Conservar foto",
                    size = 68.dp,
                    iconSize = 30.dp
                )
            }
        }
    }
}

@Composable
private fun DemoActionButton(
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    description: String,
    size: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
            disabledContainerColor = Color.White,
            contentColor = tint,
            disabledContentColor = tint.copy(alpha = 0.35f)
        ),
        shape = CircleShape,
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 10.dp, pressedElevation = 4.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
        modifier = Modifier.size(size)
            .border(1.dp, DemoLine, CircleShape)
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(iconSize))
    }
}
