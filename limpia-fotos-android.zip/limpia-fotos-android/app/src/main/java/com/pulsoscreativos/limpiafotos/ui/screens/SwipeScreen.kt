package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState
import com.pulsoscreativos.limpiafotos.ui.components.SwipeCard
import com.pulsoscreativos.limpiafotos.ui.components.SwipeDirection

/**
 * Vista Tinder, diseño moderno v1.3 (Tinder + Instagram).
 * - Sin barra superior pesada: fila mínima con volver, nombre y deshacer.
 * - Tarjeta full-bleed con los datos SOBRE la foto (como Tinder), no debajo.
 * - Acciones estilo Tinder: círculos BLANCOS con sombra, icono de color
 *   (✕ rojo, corazón verde, saltar azul, deshacer ámbar, zoom gris).
 *   Sin texto dentro ni debajo de los botones.
 * - Swipe izquierda = marcar para borrar (PASO 1, no borra).
 * - Swipe derecha = conservar.
 * - Si [reviewMode] es true, recorre solo la pila "Para borrar":
 *   swipe izquierda aquí = 2ª confirmación -> borra de verdad.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeScreen(
    state: GalleryUiState,
    startIndex: Int,
    reviewMode: Boolean = false,
    onBack: () -> Unit,
    onKeep: (Long) -> Unit,
    onMarkForDelete: (Long) -> Unit,
    onSkip: (Long) -> Unit,
    onUndo: () -> Unit,
    onConfirmDelete: (List<Photo>) -> Unit,
    onOpenDetail: (Long) -> Unit,
    onOpenReview: () -> Unit
) {
    val deck: List<Photo> = remember(state.photos, state.selectedAlbum, reviewMode) {
        if (reviewMode) state.pendingDelete else state.visiblePhotos
    }
    var index by remember(deck) { mutableIntStateOf(startIndex.coerceIn(0, (deck.size - 1).coerceAtLeast(0))) }
    val current: Photo? = deck.getOrNull(index)
    val total = state.visiblePhotos.size.coerceAtLeast(1)
    val reviewed = state.stats.reviewed

    Scaffold(
        containerColor = Color.White
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header mínimo, estilo Tinder/Instagram.
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color(0xFF111111))
                }
                Text(
                    if (reviewMode) "Revisión" else "LimpiaFotos",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111111),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                )
                if (!reviewMode && state.pendingDelete.isNotEmpty()) {
                    FilledTonalButton(
                        onClick = onOpenReview,
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Revisión (${state.pendingDelete.size})", fontSize = 13.sp, maxLines = 1)
                    }
                    Spacer(Modifier.width(8.dp))
                }
                IconButton(onClick = onUndo, enabled = state.undoStack.isNotEmpty(), modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Filled.Undo, contentDescription = "Deshacer", tint = Color(0xFF111111))
                }
            }

            // Progreso fino + contador, en una línea.
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { reviewed.toFloat() / total.toFloat() },
                    modifier = Modifier.weight(1f).height(3.dp),
                    color = Color(0xFFFE3C72),
                    trackColor = Color(0xFFF1F1F1)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    "$reviewed / $total",
                    fontSize = 12.sp,
                    color = Color(0xFF6B7280),
                    maxLines = 1
                )
            }

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }

            if (current == null) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (reviewMode) "Nada pendiente de borrar."
                            else "¡Ya revisaste todas las fotos!",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color(0xFF111111)
                        )
                        Spacer(Modifier.height(16.dp))
                        if (!reviewMode && state.pendingDelete.isNotEmpty()) {
                            Button(onClick = onOpenReview) {
                                Text("Ir a revisión (${state.pendingDelete.size})")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onBack) { Text("Volver al grid") }
                    }
                }
                return@Column
            }

            val decision = state.decisions[current.id] ?: Decision.UNDECIDED
            val onDeleteClick: () -> Unit = {
                if (reviewMode) onConfirmDelete(listOf(current))
                else { onMarkForDelete(current.id); index += 1 }
            }
            val onKeepClick: () -> Unit = {
                if (reviewMode) index += 1 else { onKeep(current.id); index += 1 }
            }

            // Tarjeta grande, casi a pantalla completa, con sombra suave.
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp)
                    .shadow(12.dp, RoundedCornerShape(24.dp))
            ) {
                SwipeCard(
                    photo = current,
                    decision = decision,
                    onTap = { onOpenDetail(current.id) },
                    onSwipe = { dir ->
                        when (dir) {
                            SwipeDirection.LEFT -> {
                                if (reviewMode) onConfirmDelete(listOf(current))
                                else onMarkForDelete(current.id)
                                index += 1
                            }
                            SwipeDirection.RIGHT -> {
                                if (!reviewMode) onKeep(current.id)
                                index += 1
                            }
                        }
                    }
                )
            }

            // Acciones estilo Tinder: círculos blancos con sombra, icono de color.
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TinderActionButton(
                    onClick = onUndo,
                    enabled = state.undoStack.isNotEmpty(),
                    icon = Icons.Filled.Undo,
                    tint = Color(0xFFFFA726),
                    description = "Deshacer",
                    size = 52.dp,
                    iconSize = 24.dp
                )
                Spacer(Modifier.width(16.dp))
                TinderActionButton(
                    onClick = onDeleteClick,
                    icon = Icons.Filled.Close,
                    tint = Color(0xFFFE3C72),
                    description = if (reviewMode) "Confirmar borrado" else "Borrar",
                    size = 72.dp,
                    iconSize = 36.dp
                )
                Spacer(Modifier.width(16.dp))
                TinderActionButton(
                    onClick = { onSkip(current.id); index += 1 },
                    icon = Icons.Filled.SkipNext,
                    tint = Color(0xFF2196F3),
                    description = "Saltar",
                    size = 52.dp,
                    iconSize = 24.dp
                )
                Spacer(Modifier.width(16.dp))
                TinderActionButton(
                    onClick = onKeepClick,
                    icon = Icons.Filled.Favorite,
                    tint = Color(0xFF00C853),
                    description = "Conservar",
                    size = 72.dp,
                    iconSize = 34.dp
                )
                Spacer(Modifier.width(16.dp))
                TinderActionButton(
                    onClick = { onOpenDetail(current.id) },
                    icon = Icons.Filled.ZoomIn,
                    tint = Color(0xFF6B7280),
                    description = "Ver detalle / zoom",
                    size = 52.dp,
                    iconSize = 24.dp
                )
            }
            Text(
                "Desliza ← para borrar  •  → para guardar",
                fontSize = 12.sp,
                color = Color(0xFF9CA3AF),
                maxLines = 1,
                modifier = Modifier.padding(top = 14.dp, bottom = 16.dp)
            )
        }
    }
}

@Composable
private fun TinderActionButton(
    onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    description: String,
    size: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, disabledContainerColor = Color.White),
        shape = CircleShape,
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp, pressedElevation = 4.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
        modifier = Modifier.size(size)
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(iconSize))
    }
}
