package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState
import com.pulsoscreativos.limpiafotos.ui.components.SwipeCard
import com.pulsoscreativos.limpiafotos.ui.components.SwipeDirection

/**
 * Vista Tinder.
 * - [startIndex] permite entrar desde el Grid empezando en esa foto exacta.
 * - Swipe izquierda = marcar para borrar (PASO 1, no borra).
 * - Swipe derecha = conservar. Botón Saltar = ver la siguiente sin decidir.
 * - Si [reviewMode] es true, esta misma pantalla recorre solo la pila
 *   "Para borrar": swipe izquierda aquí = 2ª confirmación -> borra de verdad.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeScreen(
    state: GalleryUiState,
    startIndex: Int,
    reviewMode: Boolean = false,
    onBack: () -> Unit,
    onKeep: (Long) -> Unit,
    onMarkForDelete: (Long) -> Unit,
    onSkip: (Long) -> Unit,
    onUndo: () -> Unit,
    onConfirmDelete: (List<Photo>) -> Unit,
    onOpenDetail: (Long) -> Unit,
    onOpenReview: () -> Unit
) {
    // Fotos a recorrer: en revisión solo las marcadas; si no, TODAS las
    // visibles (respetando el álbum elegido), en el mismo orden que el Grid.
    // Así el índice que llega desde el Grid apunta exactamente a esa foto.
    val deck: List<Photo> = remember(state.photos, state.selectedAlbum, reviewMode) {
        if (reviewMode) state.pendingDelete else state.visiblePhotos
    }
    var index by remember(deck) { mutableIntStateOf(startIndex.coerceIn(0, (deck.size - 1).coerceAtLeast(0))) }
    val current: Photo? = deck.getOrNull(index)
    val total = state.visiblePhotos.size.coerceAtLeast(1)
    val reviewed = state.stats.reviewed

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (reviewMode) "Revisión — Para borrar" else "Revisar fotos") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = onUndo, enabled = state.undoStack.isNotEmpty()) {
                        Icon(Icons.Filled.Undo, contentDescription = "Deshacer última acción")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Progreso + contadores de la sesión
            LinearProgressIndicator(
                progress = { reviewed.toFloat() / total.toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Revisadas $reviewed de $total  •  Conservadas ${state.stats.kept}  •  " +
                    "Para borrar ${state.stats.marked}  •  Borradas ${state.stats.deleted}",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }

            if (current == null) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (reviewMode) "Nada pendiente de borrar."
                            else "¡Ya revisaste todas las fotos!",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(Modifier.height(16.dp))
                        if (!reviewMode && state.pendingDelete.isNotEmpty()) {
                            Button(onClick = onOpenReview) {
                                Text("Ir a revisión (${state.pendingDelete.size})")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onBack) { Text("Volver al grid") }
                    }
                }
                return@Column
            }

            val decision = state.decisions[current.id] ?: Decision.UNDECIDED

            // Tarjeta grande, casi a pantalla completa
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                SwipeCard(
                    photo = current,
                    decision = decision,
                    onTap = { onOpenDetail(current.id) },
                    onSwipe = { dir ->
                        when (dir) {
                            SwipeDirection.LEFT -> {
                                if (reviewMode) {
                                    // 2º PASO: borrar de verdad esta foto.
                                    onConfirmDelete(listOf(current))
                                } else {
                                    onMarkForDelete(current.id)
                                }
                                index += 1
                            }
                            SwipeDirection.RIGHT -> {
                                if (reviewMode) {
                                    // En revisión, derecha = restaurar (no borrar).
                                    // Se maneja desde el botón Restaurar; aquí avanza.
                                    index += 1
                                } else {
                                    onKeep(current.id)
                                    index += 1
                                }
                            }
                        }
                    }
                )
            }

            // Datos rápidos de la foto actual
            Text(
                "${current.displayName}  •  ${current.resolution}  •  ${current.sizeText}  •  ${current.bucketName}",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            if (decision == Decision.MARKED_FOR_DELETE && !reviewMode) {
                Text(
                    "Marcada para borrar. Aún NO se borró: confírmala en Revisión.",
                    color = Color(0xFFE5484D),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            // Botones grandes: Conservar / Saltar / Borrar (+ Confirmar en revisión)
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        if (reviewMode) index += 1 else { onKeep(current.id); index += 1 }
                    },
                    modifier = Modifier.size(88.dp),
                    shape = MaterialTheme.shapes.extraLarge
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = Color(0xFF4ADE80))
                        Text("Conservar", style = MaterialTheme.typography.labelLarge)
                    }
                }
                FilledTonalButton(onClick = { onSkip(current.id); index += 1 }) {
                    Text("Saltar")
                }
                Button(
                    onClick = {
                        if (reviewMode) onConfirmDelete(listOf(current))
                        else { onMarkForDelete(current.id); index += 1 }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5484D)),
                    modifier = Modifier.size(88.dp),
                    shape = MaterialTheme.shapes.extraLarge
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                        Text(if (reviewMode) "Confirmar" else "Borrar")
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                OutlinedButton(onClick = { onOpenDetail(current.id) }) {
                    Icon(Icons.Filled.ZoomIn, contentDescription = null)
                    Text("Ver detalle / zoom")
                }
                if (!reviewMode) {
                    OutlinedButton(
                        onClick = onOpenReview,
                        enabled = state.pendingDelete.isNotEmpty()
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = null)
                        Text("Revisión (${state.pendingDelete.size})")
                    }
                }
            }
        }
    }
}
