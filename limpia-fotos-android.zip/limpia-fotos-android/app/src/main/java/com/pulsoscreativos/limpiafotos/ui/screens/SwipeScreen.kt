package com.pulsoscreativos.limpiafotos.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pulsoscreativos.limpiafotos.model.Decision
import com.pulsoscreativos.limpiafotos.model.Photo
import com.pulsoscreativos.limpiafotos.ui.GalleryUiState
import com.pulsoscreativos.limpiafotos.ui.components.SwipeCard
import com.pulsoscreativos.limpiafotos.ui.components.SwipeDirection

/**
 * Vista Tinder, rediseño v1.1 para parecerse a la demo web.
 * - Botones de acción circulares SOLO con icono (72 dp): ✓ conservar,
 *   ✕ borrar. El texto ya no va dentro del botón, así que no se puede
 *   partir en dos líneas ("Cons ervar", "Borra r") en ningún teléfono.
 *   La etiqueta va debajo, en letra pequeña y en una sola línea.
 * - Contadores y metadatos en una sola línea con puntos suspensivos,
 *   nada de textos largos que se desborden.
 * - Swipe izquierda = marcar para borrar (PASO 1, no borra).
 * - Swipe derecha = conservar. Botón Saltar = ver la siguiente sin decidir.
 * - Si [reviewMode] es true, esta misma pantalla recorre solo la pila
 *   "Para borrar": swipe izquierda aquí = 2ª confirmación -> borra de verdad.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeScreen(
    state: GalleryUiState,
    startIndex: Int,
    reviewMode: Boolean = false,
    onBack: () -> Unit,
    onKeep: (Long) -> Unit,
    onMarkForDelete: (Long) -> Unit,
    onSkip: (Long) -> Unit,
    onUndo: () -> Unit,
    onConfirmDelete: (List<Photo>) -> Unit,
    onOpenDetail: (Long) -> Unit,
    onOpenReview: () -> Unit
) {
    // Fotos a recorrer: en revisión solo las marcadas; si no, TODAS las
    // visibles (respetando el álbum elegido), en el mismo orden que el Grid.
    // Así el índice que llega desde el Grid apunta exactamente a esa foto.
    val deck: List<Photo> = remember(state.photos, state.selectedAlbum, reviewMode) {
        if (reviewMode) state.pendingDelete else state.visiblePhotos
    }
    var index by remember(deck) { mutableIntStateOf(startIndex.coerceIn(0, (deck.size - 1).coerceAtLeast(0))) }
    val current: Photo? = deck.getOrNull(index)
    val total = state.visiblePhotos.size.coerceAtLeast(1)
    val reviewed = state.stats.reviewed

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (reviewMode) "Revisión — Para borrar" else "Revisar fotos",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    IconButton(onClick = onUndo, enabled = state.undoStack.isNotEmpty()) {
                        Icon(Icons.Filled.Undo, contentDescription = "Deshacer última acción")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Progreso + contadores de la sesión, en una sola línea.
            LinearProgressIndicator(
                progress = { reviewed.toFloat() / total.toFloat() },
                modifier = Modifier.fillMaxWidth().height(4.dp)
            )
            Text(
                "Revisadas $reviewed de $total  •  Guardadas ${state.stats.kept}  •  " +
                    "Para borrar ${state.stats.marked}  •  Borradas ${state.stats.deleted}",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            if (state.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }

            if (current == null) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (reviewMode) "Nada pendiente de borrar."
                            else "¡Ya revisaste todas las fotos!",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Spacer(Modifier.height(16.dp))
                        if (!reviewMode && state.pendingDelete.isNotEmpty()) {
                            Button(onClick = onOpenReview) {
                                Text("Ir a revisión (${state.pendingDelete.size})")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onBack) { Text("Volver al grid") }
                    }
                }
                return@Column
            }

            val decision = state.decisions[current.id] ?: Decision.UNDECIDED

            // Tarjeta grande, casi a pantalla completa
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                SwipeCard(
                    photo = current,
                    decision = decision,
                    onTap = { onOpenDetail(current.id) },
                    onSwipe = { dir ->
                        when (dir) {
                            SwipeDirection.LEFT -> {
                                if (reviewMode) {
                                    // 2º PASO: borrar de verdad esta foto.
                                    onConfirmDelete(listOf(current))
                                } else {
                                    onMarkForDelete(current.id)
                                }
                                index += 1
                            }
                            SwipeDirection.RIGHT -> {
                                if (reviewMode) {
                                    // En revisión, derecha = restaurar (no borrar).
                                    // Se maneja desde el botón Restaurar; aquí avanza.
                                    index += 1
                                } else {
                                    onKeep(current.id)
                                    index += 1
                                }
                            }
                        }
                    }
                )
            }

            // Datos rápidos de la foto actual, en una sola línea.
            Text(
                "${current.displayName}  •  ${current.resolution}  •  ${current.sizeText}",
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp)
            )
            if (decision == Decision.MARKED_FOR_DELETE && !reviewMode) {
                Text(
                    "Marcada para borrar. Aún NO se borró: confírmala en Revisión.",
                    color = Color(0xFFE5484D),
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Acciones: círculos solo con icono, como la demo.
            // Conservar (verde, ✓) — Saltar (texto) — Borrar (rojo, papelera).
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        if (reviewMode) index += 1 else { onKeep(current.id); index += 1 }
                    },
                    modifier = Modifier.size(72.dp),
                    shape = CircleShape,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF4ADE80))
                ) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = "Conservar",
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(Modifier.width(28.dp))
                FilledTonalButton(
                    onClick = { onSkip(current.id); index += 1 },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("Saltar", maxLines = 1)
                }
                Spacer(Modifier.width(28.dp))
                Button(
                    onClick = {
                        if (reviewMode) onConfirmDelete(listOf(current))
                        else { onMarkForDelete(current.id); index += 1 }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5484D)),
                    modifier = Modifier.size(72.dp),
                    shape = CircleShape,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) {
                    Icon(
                        Icons.Filled.Delete,
                        contentDescription = if (reviewMode) "Confirmar" else "Borrar",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
            // Etiquetas bajo los círculos, letra pequeña, una sola línea.
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Conservar",
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier.width(72.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.width(28.dp))
                Text(
                    "",
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier.width(64.dp)
                )
                Spacer(Modifier.width(28.dp))
                Text(
                    if (reviewMode) "Confirmar" else "Borrar",
                    fontSize = 12.sp,
                    maxLines = 1,
                    modifier = Modifier.width(72.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TextButton(
                    onClick = { onOpenDetail(current.id) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.ZoomIn, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Ver detalle / zoom", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (!reviewMode) {
                    TextButton(
                        onClick = onOpenReview,
                        enabled = state.pendingDelete.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "Revisión (${state.pendingDelete.size})",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
