package com.pulsoscreativos.limpiafotos.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Paleta oscura por defecto (la app es de revisión de fotos: fondo negro
// para ver bien la calidad). Rojo = borrar, verde = conservar.
private val DarkColors = darkColorScheme(
    primary = Color(0xFFE5484D),
    secondary = Color(0xFF16A34A),
    tertiary = Color(0xFF60A5FA),
    background = Color(0xFF0A0A0A),
    surface = Color(0xFF161616),
    surfaceVariant = Color(0xFF232323),
    onBackground = Color(0xFFF5F5F5),
    onSurface = Color(0xFFF5F5F5),
    error = Color(0xFFE5484D)
)
private val LightColors = lightColorScheme(
    primary = Color(0xFFE5484D),
    secondary = Color(0xFF16A34A),
    tertiary = Color(0xFF2563EB),
    background = Color.White,
    surface = Color.White,
    surfaceVariant = Color(0xFFF1F1F1),
    onBackground = Color(0xFF111111),
    onSurface = Color(0xFF111111),
    onSurfaceVariant = Color(0xFF6B7280),
    error = Color(0xFFE5484D)
)

@Composable
fun LimpiaFotosTheme(
    darkTheme: Boolean = false, // tema blanco, como la demo que probó Cesar
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}

// Re-export para no depender de isSystemInDarkTheme en las pantallas.
@Composable
fun isDark(): Boolean = isSystemInDarkTheme()
