// Top-level build file — LimpiaFotos
// Versiones estables verificadas: AGP 8.5.2 + Kotlin 2.0.21 + Compose BOM 2024.09.00
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
